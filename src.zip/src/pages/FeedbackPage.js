import React from 'react';
import FeedbackForm from '../components/Form';

const FeedbackPage = () => {
  return (
    <div className='container mt-5'>
        <h1>&nbsp;</h1>
      
      <div className='row'>
        
        <div className='col-sm-6'>
            <FeedbackForm />
        </div>
      </div>
      
    </div>
  );
};

export default FeedbackPage;
