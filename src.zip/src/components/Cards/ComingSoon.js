import React from "react";

const ComingSoon = () => {
    return(
        
            <h4 className="">Coming Soon...</h4>
       
    )
};

export default ComingSoon;